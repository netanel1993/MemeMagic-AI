
import React from 'react';
import { MemeTemplate } from '../types';

const TRENDING_TEMPLATES: MemeTemplate[] = [
  { id: '1', name: 'Distracted Boyfriend', url: 'https://picsum.photos/id/10/800/600' },
  { id: '2', name: 'Success Kid', url: 'https://picsum.photos/id/20/800/600' },
  { id: '3', name: 'Doge vibe', url: 'https://picsum.photos/id/237/800/600' },
  { id: '4', name: 'Two Buttons', url: 'https://picsum.photos/id/40/800/600' },
  { id: '5', name: 'Confused Guy', url: 'https://picsum.photos/id/64/800/600' },
  { id: '6', name: 'Epic Handshake', url: 'https://picsum.photos/id/82/800/600' },
];

interface Props {
  onSelect: (url: string) => void;
}

export const TemplateGallery: React.FC<Props> = ({ onSelect }) => {
  return (
    <div className="space-y-4">
      <h3 className="text-xl font-bold text-slate-200">Trending Templates</h3>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {TRENDING_TEMPLATES.map((t) => (
          <button
            key={t.id}
            onClick={() => onSelect(t.url)}
            className="group relative overflow-hidden rounded-lg border-2 border-slate-700 hover:border-indigo-500 transition-all"
          >
            <img 
              src={t.url} 
              alt={t.name} 
              className="aspect-square object-cover w-full group-hover:scale-110 transition-transform duration-300"
            />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
              <span className="text-xs font-bold text-white bg-indigo-600 px-2 py-1 rounded">USE THIS</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
