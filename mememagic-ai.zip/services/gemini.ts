
import { GoogleGenAI, Type } from "@google/genai";

const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
};

/**
 * Helper to parse a data URL into its components.
 */
const parseDataUrl = (dataUrl: string) => {
  const matches = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  if (!matches) {
    // Fallback if it's just raw base64 or a malformed string
    return { mimeType: 'image/jpeg', data: dataUrl.split(',')[1] || dataUrl };
  }
  return { mimeType: matches[1], data: matches[2] };
};

/**
 * Analyzes the image and returns 5 funny meme captions using Gemini 3 Pro Preview.
 */
export const getMagicCaptions = async (base64Image: string): Promise<string[]> => {
  const ai = getAIClient();
  const { mimeType, data } = parseDataUrl(base64Image);

  if (!data) throw new Error("Invalid image data provided to AI service.");

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: mimeType,
            data: data,
          },
        },
        {
          text: "Analyze this image and suggest 5 hilarious, short, and trendy meme captions that would fit this context perfectly. Return only a JSON array of 5 strings. Each string should represent a possible meme text (keep them punchy).",
        },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: { type: Type.STRING },
      },
    },
  });

  try {
    const text = response.text;
    return JSON.parse(text || '[]');
  } catch (e) {
    console.error("Failed to parse AI captions", e);
    return [];
  }
};

/**
 * Uses Gemini 2.5 Flash Image to edit an image based on a text prompt.
 */
export const editImageWithAI = async (base64Image: string, prompt: string): Promise<string | null> => {
  const ai = getAIClient();
  const { mimeType, data } = parseDataUrl(base64Image);

  if (!data) throw new Error("Invalid image data provided to AI service.");

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: mimeType,
            data: data,
          },
        },
        {
          text: prompt,
        },
      ],
    },
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }

  return null;
};
